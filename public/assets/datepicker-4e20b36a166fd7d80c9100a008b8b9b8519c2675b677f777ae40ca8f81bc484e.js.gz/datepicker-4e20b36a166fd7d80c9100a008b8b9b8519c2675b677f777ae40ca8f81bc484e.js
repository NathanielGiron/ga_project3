$(document).ready(function() {
	$(function() {
		$('.datepicker').datepicker({format: 'yyyy-mm-dd'});
	});
});
